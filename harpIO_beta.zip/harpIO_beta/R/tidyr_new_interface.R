tidyr_new_interface <- function() {
  packageVersion("tidyr") > "0.8.99"
}
