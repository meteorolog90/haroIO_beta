#' Generate options for obsoul files
#'
#' @param type Type of obsoul - "synop" or "temp"
#' @param missing_value Missing value indicator. Default is -99.0
#' @param synop_cols For vfld/vobs version < 4 the column names in the files
#'   are assumed. Use \code{synop_cols} to override the defaults for SYNOP
#'   data. Note that the variable names used here must be valid vfld/vobs
#'   names.
#' @param temp_cols For vfld/vobs version < 4 the column names in the files
#'   are assumed. Use \code{temp_cols} to override the defaults for TEMP data.
#'   Note that the variable names used here must be valid vfld/vobs names.
#'
#' @return A list of options
#' @export
#'
#' @examples
#' obsoul_opts()
#' obsoul_opts(type = "synop")
#' obsoul_opts(missing_value = -555)
obsoul_opts <- function(
  type          = c("synop", "temp"),
  missing_value = -99.0,
  synop_cols    = NULL,
  temp_cols     = NULL
) {

  type <- match.arg(type)

  list(
    type = type,
    missing_value = missing_value,
    synop_cols    = synop_cols,
    temp_cols     = temp_cols
  )

}
